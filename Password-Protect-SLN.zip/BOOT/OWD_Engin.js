﻿function doSearch() {
    window.location.href = frbaseurl + "/" + replaceallstr($("#s").val(), " ", "-");
}
function callSubmitForm(id) {
    //alert(1);
    tim1 = setInterval(startCallSubmitForm, 100, id);
}
function startCallSubmitForm(id) {
    clearInterval(tim1);
    //alert(id);
    submitForm($("#" + id));
    return false;
}

function submitForm(frm) {

    // return;


    var dcJ = getFormDic($(frm).attr("id"));
    waitint = setInterval(check_submit_result, 100);
    var pg = $(frm).attr("action");
    var cmd = $(frm).attr("cmd");
    window.parent.submit_win_form(wid, cmd, dcJ, pg);

    return;// false;
}

function getFormDic(formId) {

    var dcol = new Array();



    // var formObj = {};
    var inputs = $('#' + formId).serializeArray();
    $.each(inputs, function (i, input) {
        //formObj[input.name] = input.value;
        //console.log(input.name + " = " + input.value);
        dc = new window.parent.dic(input.name, escape(input.value));
        dcol[dcol.length] = dc;
    });
    return dcol;
}

var tim1 = "";
$(document).ready(function () {
    //keep_me_open();
    tim1 = setInterval(fnc1, 3000);
});
function fnc1() {
    clearInterval(tim1);
    //submitForm($("#loginFrm"));
}
var waitint = "";
var wid = "win" + gettimetick();
function check_submit_result() {
    //window.parent.show_wait();
    var res = window.parent.get_win_cmd_result(wid);
    if (res != "wait") {
        clearInterval(waitint);
        window.parent.hide_wait();
        try {
            var resAr = res.split("#n$#");
            console.log(resAr[0]);
            switch (resAr[0]) {

                case "nothing":
                    //
                    break;
                case "script":
                    console.log(resAr[1]);
                    eval(resAr[1]);
                    break;
                case "reload":
                    window.location.href = window.location.href;
                    break;
                case "redirect":
                    window.location.href = resAr[1];
                    break;
                case "replace":
                    //
                    break;
            }
        } catch (ex) {
            console.log("Error in Response : " + "\n" + ex.message + "\n" + res);
        }
        //eval(res);
    }
}
function dic(name, val) {
    this.val = val;
    this.name = name;
}

function loadElement(source, target) {
    formdata = "load" + "#newitem#";
    servpg = source;
    cmdval = "loadElement";
    silent = false;
    //show_wait();
    callajax(formdata, servpg, cmdval, silent, target);
}
function loadElement_finish(rv, params) {
    $("#" + params).html(rv);
}

function submit_win_form(wid, cmd, dcol, pg) {

    add_win_cmd(wid);

    var name = cmd;
    var vals = "";
    for (var i = 0; i <= dcol.length - 1; i++) {
        vals += dcol[i].name + "#np#" + dcol[i].val + "#nd#";
    }

    //alert(vals);
    if (true) {


        formdata = name + "#newitem#" + vals;

        servpg = pg;//"Actions/sendformReell";
        cmdval = "submit_win_form";
        silent = false;

        //alert(3);
        show_wait();

        callajax(formdata, servpg, cmdval, silent, wid);
        // console.log("not error");
        //////alert("call");
    }
}
function submit_win_form_finish(rv, params) {
    ////alert(params);
    for (var i = 0; i <= win_cmd_results.length - 1; i++) {
        if (win_cmd_results[i].name == params) {
            //alert(rv);
            win_cmd_results[i].val = rv;
        }
    }



    hide_wait();

}
var win_cmd_results = new Array();
var win_listeners = new Array();

function add_2_winListeners(id, val) {
    var wdc = new dic(id, val);
    win_listeners[win_listeners.length] = wdc;
    // ////alert(win_listeners.length);

    //////alert("add : " + id);

}

function write_2_winListeners(id, val) {

    //////alert("write : " + id + " - " + val);

    for (var i = win_listeners.length - 1; i >= 0 ; i--) {
        if (win_listeners[i].name == id) {
            win_listeners[i].val = val;
            break;
        }
    }
}

function read_from_winListeners(id) {
    for (var i = win_listeners.length - 1; i >= 0 ; i--) {
        if (win_listeners[i].name == id) {

            return win_listeners[i].val;
        }
    }
}

function add_win_cmd(wid) {

    var f = false;
    for (var i = 0; i <= win_cmd_results.length - 1; i++) {
        if (win_cmd_results[i].name == wid) {
            f = true;
            win_cmd_results[i].val = "wait";
        }
    }
    if (f == false) {
        var wdc = new dic(wid, "wait");
        win_cmd_results[win_cmd_results.length] = wdc;
    }

}


function get_win_cmd_result(wid) {
    for (var i = 0; i <= win_cmd_results.length - 1; i++) {
        if (win_cmd_results[i].name == wid) {
            return win_cmd_results[i].val;
        }
    }
}


var int_get_us_cmd = "";
function keep_me_open() {
    //////alert(1);
    clearInterval(int_get_us_cmd);
    int_get_us_cmd = setInterval(get_us_cmd, 7000);
}

function get_us_cmd() {

    clearInterval(int_get_us_cmd);
    //////alert(2);
    //if (in_logout == false) {
    formdata = "get_us_cmd";

    servpg = "Actions/get_us_cmd";
    cmdval = "get_us_cmd";
    silent = true;
    callajax(formdata, servpg, cmdval, silent, '');
    //}
}

function get_us_cmd_finish(rv, params) {
    //////alert(3);
    // console.log("us cmd : " + rv);
    retvsec = rv;
    if ((rv.toLowerCase().indexOf('error') > -1) || (rv.toLowerCase().indexOf('found') > -1)) {

        redirect2login();

    } else {

        nfnum = 0;

        //int_get_us_cmd = setInterval(get_us_cmd, 7000);
    }

    int_get_us_cmd = setInterval(get_us_cmd, 7000);

}


function redirect2login() {
    console.log("us cmd : " + "*************** INTERNET NOT GOOD ****************");
}


function replaceallstr(ts, tv, rv) {
    while (ts.indexOf(tv) > -1) {
        ts = ts.replace(tv, rv);
    }
    return ts;
}

function gettimetick() {
    var date = new Date();
    var ticks = date.getTime();
    return ticks;
}

function isnullval(tval) {
    retval = false;
    try {
        if ((tval == "") || (tval == undefined) || (tval == null) || (jQuery.trim(tval) == "")) { retval = true; }
    } catch (ex) {
        retval = false;
    }
    return retval;
}

var delayint = "";
function do_by_delay(cmd, sec) {
    delayint = setInterval(do_by_delay_func, sec, cmd);
}
function do_by_delay_func(cmd) {
    clearInterval(delayint);
    //////alert(cmd);
    eval(cmd);
}

var getuscmdint;
var errsrpt = "";
var proccessque = new Array();
var proccessint = "";
var ajaxfree = true;
var trycatchque = new Array();
var latestpid = -1;
var latestxhr = null;
//var frbaseurl = "http://localhost:4096";
var cancle_ajax = false;


$(document).ready(function () {
    proccessint = setInterval(proccesscheker, 1000);
});

function proccesscheker() {
    if (ajaxfree == true) {
        for (var i = 0; i <= proccessque.length - 1; i++) {
            if ((proccessque[i].done == false) && (proccessque[i].finish == false) && (proccessque[i].inproccess == false)) {
                //ajaxfree = false;
                proccessque[i].inproccess = true;
                //callajax2(proccessque[i].formdata, proccessque[i].servpg, proccessque[i].cmdval, proccessque[i].silent, proccessque[i].params, ("proccessid=" + i));
                callajax2(proccessque[i].formdata, proccessque[i].servpg, proccessque[i].cmdval, proccessque[i].silent, proccessque[i].params, (i));
                break;
            }
        }
    }

    for (var i = 0; i <= trycatchque.length - 1; i++) {
        if ((trycatchque[i].finish == false) && (trycatchque[i].inproccess == false)) {
            try {
                trycatchque[i].inproccess = true;
                eval(trycatchque[i].cmd);
                trycatchque[i].finish = true;
            } catch (ex) {
                trycatchque[i].retry += 1;
                trycatchque[i].inproccess = false;
            }
            break;
        }
    }
}

function retryproccess(pid, data) {
    console.log("retry " + pid);
    if (cancle_ajax == false) {
        proccessque[pid].retry++;
        proccessque[pid].inproccess = false;
        if (proccessque[pid].retry >= 10) {
            //seterr(pid);
            proccessque[pid].finish = true;
        }
        ajaxfree = true;
    } else {
        cancle_ajax = false;
        proccessque[pid].finish = true;
    }
}

function finishproccess(pid, data) {
    proccessque[pid].finish = true;
    //////alert(proccessque[pid].params);
    //finishfunc = proccessque[pid].cmdval + "_finish(data," + proccessque[pid].params + ")";

    if (cancle_ajax == false) {
        finishfunc = proccessque[pid].cmdval + "_finish(data,proccessque[pid].params)";
        eval(finishfunc);
    } else {
        cancle_ajax = false;
    }

    proccessque[pid].done = true;
    ajaxfree = true;
}

function actioncaller(method, calltype, params, inputs, rettype, silentwait, slientlog, callbackmethod, container) {
    var proccessobj = new Object();
    proccessobj.method = method;
    proccessobj.calltype = calltype;
    proccessobj.params = params;
    proccessobj.inputs = inputs;
    proccessobj.rettype = rettype;
    proccessobj.silentwait = silentwait;
    proccessobj.slientlog = slientlog;
    proccessobj.callbackmethod = callbackmethod;
    proccessobj.container = container;
    proccessobj.inproccess = false;
    proccessobj.finish = false;
    proccessobj.done = false;
    proccessobj.retry = 0;
    proccessque[proccessque.length] = proccessobj;
    if (silentwait == false) { waitlevel++; loadqnum2++; }
}

function add2trycatchque(tcmd) {
    var proccessobj = new Object();
    proccessobj.cmd = tcmd;
    proccessobj.finish = false;
    proccessobj.retry = 0;
    proccessobj.inproccess = false;
    trycatchque[trycatchque.length] = proccessobj;
}


function callajax(formdata, servpg, cmdval, silent, params) {

    //////alert(cancle_ajax);

    if (servpg.indexOf("Shell") == -1) {
        //alert(4);
        callajax0(formdata, servpg, cmdval, silent, params);
    } else {
        //alert(5);
        var proccessobj = new Object();
        proccessobj.formdata = formdata;
        proccessobj.servpg = servpg;
        proccessobj.cmdval = cmdval;
        proccessobj.silent = silent;
        proccessobj.params = params;
        proccessobj.inproccess = false;
        proccessobj.finish = false;
        proccessobj.done = false;
        proccessobj.retry = 0;
        proccessque[proccessque.length] = proccessobj;
        //////alert(22);
    }
}

var dcn = 0;
var intcallret = "";
var pid4Retry = "";
function callRetry() {
    clearInterval(intcallret);
    retryproccess(pid4Retry, "");
}
function callajax2(formdata, servpg, cmdval, silent, params, pid) {
  //  console.log("call " + cmdval);
    try {
        retval = "";

        ajaxfree = false;
        cancle_ajax = false;
        latestpid = pid;

        if (silent == false) { //show_wait();
        }

        //////alert(222);
        if (window.location.href.indexOf('://www.') > -1) {
            if (frbaseurl.indexOf('://www.') == -1) {
                frbaseurl = frbaseurl.replace('://', '://www.');
            }
        }
        var foo = '<?xml version="1.0" ?>\n<item><![CDATA[' + formdata + ']]></item>';
        $.ajax({
            url: frbaseurl + "/" + servpg + '?codepass=' + sessionucode + '&CmdName=' + cmdval + "&params=" + params + "&pid=" + pid,
            type: 'POST',
            contentType: 'text/xml',
            data: foo,
            success: function (data) {
                dcn = 0;
                //alert("data: " + data);
                if (data != "ERROR") {

                    //////alert(data);
                    proccessid = parseInt((GetTargetVarFromHttpResponseText("pid", data)));
                    //////alert(proccessid);
                    actionresult = (GetTargetVarFromHttpResponseText("result1", data));
                    if (silent == false) {
                        retval = (GetTargetVarFromHttpResponseText("result1", data));
                        if (retval != "ok") {
                            //////alert(retval);
                            if (proccessque[proccessid].finish == false) {
                                //////alert(". خطا در برقراری ارتباط با سرور");
                                redirect2login('ajax');
                                showErr("خطا در برقراری ارتباط با سرور222 ");
                            }
                            retval = "err";
                        } else {
                            retval = data;
                        }
                    } else {
                        retval = data;
                    }
                    //finishfunc = cmdval + "_finish(retval,params)";
                    //eval(finishfunc);
                    //actionresult = "ok";
                    //////alert(1);
                    if (actionresult == "ok") {
                        //////alert(2);
                        if (proccessque[proccessid].finish == false) {
                            //////alert(3);
                            finishproccess(proccessid, retval);
                        }
                    } else {
                    //    alert("retry2");
                        //if (cancle_ajax == false) {
                        if (proccessque[proccessid].finish == false) {
                            retryproccess(proccessid, retval);
                        } else {
                            //finishproccess(proccessid, retval);
                        }
                    }



                } else {
                    redirect2login('ajax');
                    showErr("خطا در برقراری ارتباط با سرور333 ");
                }

                if (silent == false) { hide_wait(); }

            },
                error: function (request, status, error) {
                    //alert("ERR OCC : " + "status=" + status + " - error: " + error + " - resp: " + request.responseText);
                    console.log("ERR OCC : " + "status=" + status + " - error: " + error + " - resp: " + request.responseText);
                    if (status == "error") {// (request.responseText == undefined) {
                     //   alert("retry1");
                        dcn++;
                        console.log("disconnect : " + dcn);
                        if (dcn >= 10) {
                            showDC();
                        } else {
                            //retryproccess(pid, "");
                            pid4Retry = pid;
                            intcallret = setInterval(callRetry, 1000);
                            //ajaxfree = true;
                        }
                    }
                },
            beforeSend: function (xhr) {
                //////alert("send");
                //xhr.setRequestHeader('Content-length', foo.length);
                //xhr.setRequestHeader('Connection', 'close');
                //xhr.abort();
                latestxhr = xhr;

            }
        });

        // $(document).ajaxStop();
    } catch (ex) {
        alert("ajax err");
        redirect2login('ajax');
        showErr("خطا در برقراری ارتباط با سرور444 ");
    }

}

function showDC() {
    //alert("you are disconnected !");
    showErr($("#internetErr").html());
    getuscmdint = setInterval(getuscommandlist, 1000);
    //dcn = 0;
    ajaxfree = true;
}

function callajax0(formdata, servpg, cmdval, silent, params) {
    try {
        retval = "";
        //alert(6);
        ////alert(frbaseurl);
        ////alert(servpg);
        //////alert(frbaseurl + "/" + servpg + '?codepass=' + sessionucode + '&CmdName=' + cmdval + "&" + params);

        ajaxfree = false;
        cancle_ajax = false;

        if (silent == false) {
            //show_wait();
        }

        if (window.location.href.indexOf('://www.') > -1) {
            if (frbaseurl.indexOf('://www.') == -1) {
                frbaseurl = frbaseurl.replace('://', '://www.');
            }
        }

        var turl = frbaseurl + "/" + servpg + '?codepass=' + sessionucode + '&CmdName=' + cmdval + "&" + params;

        if (servpg.indexOf("this::") > -1) {
            servpg = servpg.replace("this::", "");
            turl = servpg + '?codepass=' + sessionucode + '&CmdName=' + cmdval + "&" + params;
        }

        var foo = '<?xml version="1.0" ?>\n<item><![CDATA[' + formdata + ']]></item>';
        $.ajax({
            url: turl,
            type: 'POST',
            contentType: 'text/xml',
            data: foo,
            success: function (data) {

                ////alert(data);

                if (data != "ERROR") {

                    retval = data;
                    //////alert(data);
                    //if (silent == false) {
                    //    retval = (GetTargetVarFromHttpResponseText("result1", data));
                    //    if (retval != "ok") {
                    //        ////alert(data); 
                    //        //////alert(params);
                    //        //if (proccessque[proccessid].finish == false) {
                    //        //////alert(". خطا در برقراری ارتباط با سرور");
                    //        showErr("خطا در برقراری ارتباط با سرور ");
                    //        //}
                    //        retval = "err";
                    //    } else {
                    //        retval = data;
                    //    }
                    //} else {
                    //    retval = data;
                    //}
                    //if (proccessque[proccessid].finish == false) {
                    finishfunc = cmdval + "_finish(retval,params)";
                    eval(finishfunc);
                    //} else {
                    //cancle_ajax = false;
                    //}



                } else {
                    redirect2login('ajax');
                    showErr("555خطا در برقراری ارتباط با سرور ");
                }

                if (silent == false) { hide_wait(); }

            },
            beforeSend: function (xhr) {
                //////alert("send");
                //xhr.setRequestHeader('Content-length', foo.length);
                //xhr.setRequestHeader('Connection', 'close');
                latestxhr = xhr;
                //////alert(11);
            }
        });

    } catch (ex) {
        //alert(formdata + "9");
        //alert(servpg + "8");
        //alert(cmdval + "7");
        //alert(silent + "6");
        //alert(params + "5");
        redirect2login('ajax');
        showErr("خطا در برقراری ارتباط با سرور6666 ");
    }
}

function GetTargetVarFromHttpResponseText(VarName, CollStr) {
    try {
        var TargetValue = "";
        var CollectionStr = CollStr;
        var i;
        var TempArr = new Array();
        var TempArr2 = new Array();
        TempArr = CollectionStr.split("&");
        for (i = 0; i < TempArr.length; i++) {
            TempArr2 = TempArr[i].split("=");
            if (TempArr2.length = 2) {
                if (TempArr2[0] == VarName) {
                    TargetValue = TempArr2[1];
                    break;
                }
            }
        }
        do {
            TargetValue = TargetValue.replace("#EQ#", "=");
        } while (TargetValue.indexOf("#EQ#") > -1)

        return TargetValue;
    } catch (ex) {
        //donothing
    }
}
