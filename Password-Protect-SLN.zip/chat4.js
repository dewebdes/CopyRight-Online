$(function(){
//socket = io.connect('https://ice.telnet.center',{secure: true})
socket = io.connect('http://176.9.28.92:6907')

socket.on('connect', function() {
	console.log('connect');
	
	//connectmedia();
	if(inwaitmod == "getstreamlist"){
		inwaitmod = "";
		//socket.emit("getliststreams","");
	}
});

socket.on("getfile", (data) => {
	console.log(data.fn);
	console.log(data.bin);
	
	$("#pdfviewer").attr("src", URL.createObjectURL(new Blob([data.bin], {
        type: "application/pdf"
    })))
	
})

socket.on("addstream", (data) => {
	if(inwaitmod == "addstream"){
		inwaitmod = "";
		InitStream();
	}
	var el = $($('#streamlist p')[0]).clone();
	var htm = $(el).html();
	htm = htm.replace("{tit}",data.skid).replace("{tit}",data.skid);
	$(el).html(htm).show();
	$('#streamlist').append($(el));
})
socket.on('hideprotect', function(msg){
	window.clearInterval(window.intu1);
	jQuery(jQuery('body > div.modal-overlay.modal-overlay-visible')[0]).hide();
	jQuery(jQuery('body > div.modal.modal-in')[0]).hide();
});
socket.on('checkpassprotect', function(msg){
	if(msg=="er"){lps="";}else{
    
    console.log(msg.fn);
   var els=document.getElementsByClassName('cpr');
   //els[0].src = 'data:image/jpeg;base64,' + (msg.bin);
   for(var i=0;i<=els.length-1;i++){
   	   //console.log(els[i].src);
   	   //console.log(els[i].src.indexOf(msg.fn+'-fade'));
   	   //console.log(msg.fn+'-fade');
 if(els[i].src.indexOf(msg.fn.split('.')[0]+'-fade')>-1){
 	 
console.log('found');
   els[i].src = 'data:image/jpeg;base64,' + (msg.bin);
}
}
}
});
socket.on("setliststreams", (data) => {
	for(var i=0;i<=data.length-1;i++){
		var el = $($('#streamlist p')[0]).clone();
		var htm = $(el).html();
		htm = htm.replace("{tit}",data[i].skid).replace("{tit}",data[i].skid);
		$(el).html(htm).show();
		$('#streamlist').append($(el));
	}
})

});




