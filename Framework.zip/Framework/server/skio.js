'use strict'
var streamLength = require("stream-length");

var fs = require("fs");
var uuid = require('node-uuid');
var port = process.argv[2] || 9669;
var path = require('path');
var exec = require('child_process').exec;

const Stream = require('stream')

var spawn = require('child_process').spawn;


var app0 = require('express')();
//app0.use(express.static('static'));
var http0 = require('http').createServer(app0);
http0.timeout = 0;
var SocketIO = require('socket.io');
var io = SocketIO({
  perMessageDeflate: false // Disable compression
}).listen(http0);

var bufferHeader = null;

var url = require('url');
io.on('error',function(e){
	console.log('socket.io error:'+e);
});

spawn('ffmpeg',['-h']).on('error',function(m){
	console.error("FFMpeg not found in system cli; please install ffmpeg properly or make a softlink to ./!");
	process.exit(-1);
});



function objToString (obj) {
	var str = '';
	for (var p in obj) {
	if (obj.hasOwnProperty(p)) {
	str += p + '::' + obj[p] + '\n';
	}
	}
	return str;
}

var iolog = function() {};

for (var i = 0; i < process.argv.length; i++) {
  var arg = process.argv[i];
  if (arg === "-debug") {
    iolog = function(msg) {
      //console.log(msg);
    };
    //console.log('Debug mode on!');
  }
}

// generate a 4 digit hex code randomly
function S4() {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}

// make a REALLY COMPLICATED AND RANDOM id, kudos to dennis
function id() {
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

function notifydevice(id){
	

	var sockets = io.sockets.sockets;
	for(var socketId in sockets)
	{
	  var socket = sockets[socketId]; //loop through and do whatever with each connected socket
	  //...
	  if(socket.device==id){
			socket.emit("runnotify","");
		}
	}

}
app0.get('/', function(req, res){
  res.send('<h1>Hello world, My name is Telnet Media Server Center.</h1>');
});


var StreamsArr = new Array();
function streamobj(skid,barr,soft,device,cam,mic){
	this.skid = skid;
	this.barr = barr;
	this.soft = soft;
	this.device = device;
	this.cam = cam;
	this.mic = mic;
}
function saveBlob(skid,blb,soft,device){
	//insert into wp_ipz_stream (sid,dkey,dsoft,dplat,tit,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#key#sq#,#sq#soft#sq#,#sq#plat#sq#,#sq#tit#sq#,0,0,1,0,0)
	var fnd = false;
	for(var i=0;i<=StreamsArr.length-1;i++){
		if(StreamsArr[i].skid == skid){
			fnd = true;
			//for(var j=0;j<=blb.length-1;j++){
				StreamsArr[i].barr[StreamsArr[i].barr.length] = blb;//[j];
				//console.log('push - '+StreamsArr[i].barr.length);

			//}
		}
	}
	if(fnd==false){
		var nar = new Array();
		nar[0] = blb;
		var nc = new streamobj(skid,nar,soft,device);
		StreamsArr[StreamsArr.length] = nc;
		//console.log('add - ');
	}
}

io.origins('*:*');

io.on('connection', function(socket){

	iolog('connect');

    socket.id = id();
	socket.emit('setmyid', socket.id);
    console.log('new socket got id: ' + socket.id);

socket.targetmic = "";

  socket.ip = "";
  socket.sys = "";
  socket.tkn = "";
  socket.project = "";
  socket.device = "0";
  var address = socket.handshake.address;
  socket.ip = address.address+":"+address.port;
  var socketId = socket.id;
  //var clientIp = request.connection.remoteAddress;//socket.request.connection.remoteAddress;
var ip = socket.handshake.headers ['x-forwarded-for'];//socket.handshake.headers ['X-FORWARDED-FOR'];//socket.request.connection._peername.address;//socket.handshake.address;//socket.handshake.headers ['X-FORWARDED-FOR'];//socket.ip;//socket.request.connection.remoteAddress;
socket.ip = ip;
 //console.log(JSON.stringify(socket.handshake.headers));
  socket.on('disconnect', function(){
    ////console.log('user disconnected');
  });


//###################
/* Presenter */
	socket.on('getmic', function(msg){
		socket.targetmic = msg;
	});

    socket.on('bufferHeader', function(packet){
        // Buffer header can be saved on server so it can be passed to new user
	console.log("BufferHeader - "+socket.id);
//socket.broadcast.emit('stream', packet);

//targetmic 
        bufferHeader = packet;

var sockets = io.sockets.sockets;
for(var socketId in sockets)
{
  var sok = sockets[socketId]; //loop through and do whatever with each connected socket
  //console.log("=> "+sk.id);
	if(sok.targetmic == socket.id){
	       	sok.emit('bufferHeader', packet);
	}

}
/*
var clients = io.sockets.clients();
console.log("sockets = "+clients.length);
for(var i=0;i<=io.sockets.length-1;i++){
	var sok = io.sockets[i];
	//io.sockets.clients().forEach(function (sok) {  
		if(sok.targetmic == socket.id){
	        	sok.emit('bufferHeader', packet);
		}
	}//);
*/
    });

    // Broadcast the received buffer
    socket.on('stream', function(packet){
	//console.log("stream - "+socket.id);

        socket.broadcast.emit('stream', packet);
    });

    // Send buffer header to new user
    socket.on('requestBufferHeader', function(){
	console.log("requestBufferHeader - "+socket.id);
        socket.emit('bufferHeader', bufferHeader);
    });
//##################

socket.on('getstreamdata', function(msg){
	var strmobj;
	for(var i=0;i<=StreamsArr.length-1;i++){
		var nc = StreamsArr[i];
		if(nc.skid == msg){		
			nc.blb = null;
			strmobj = nc;
			break;
		}
  	}
  	socket.emit("setstreaminfo",strmobj);

});

socket.on('andcreatestream', function(msg){
	console.log("new stream add : "+socket.id);
	var dt = new Array();
	var nc = new streamobj(socket.id,dt,"telnet","android",true,true);
	StreamsArr[StreamsArr.length] = nc;
	io.sockets.emit("addstream",nc);
});
socket.on('createstream', function(msg){
	var dt = new Array();
	var nc = new streamobj(socket.id,dt,msg.soft,msg.device,msg.cam,msg.mic);
	StreamsArr[StreamsArr.length] = nc;
	io.sockets.emit("addstream",nc);
});

socket.on('getliststreams', function(msg){
	var outx = new Array();
	for(var i=0;i<=StreamsArr.length-1;i++){
		var nc = StreamsArr[i];
		nc.blb = null;
  		outx[outx.length] = nc;// {skid:StreamsArr[i].skid,cam:StreamsArr[i].cam,mic:StreamsArr[i].mic};
  	}
  	socket.emit("setliststreams",outx);
});


socket.on('saveblob', function(msg){
	//console.log("save blobs :: "+msg.length);
	////console.log("save blobs :: "+msg);
	saveBlob(socket.id,msg,'web','chrome');
});

//gotpush
socket.on('gotpush', function(msg){
	////console.log("save blobs :: "+msg.length);
	////console.log("save blobs :: "+msg);
//blb:dt, dskid:firstid
	saveBlob(msg.dskid,msg.blb,'web','chrome');
});

//getnextbufer
socket.on('getnextbufer', function(msg){
	var arx = msg.split('---');
	var dtsk = arx[0];
	var dindx = parseInt(arx[1]);
	var dbdb = new Array();
	for(var i=0;i<=StreamsArr.length-1;i++){
		if(StreamsArr[i].skid == dtsk){
  			for(var j=dindx;j<=StreamsArr[i].barr.length-1;j++){
				dbdb[dbdb.length] = StreamsArr[i].barr[j];
				if((j-dindx)==300){break;}
			}
			break;		
		}
  	}

	socket.emit("addnewbuf",dbdb);
});


socket.on('getstreams', function(msg){
  if(msg.length==0){
  	var outx = "";
  	for(var i=0;i<=StreamsArr.length-1;i++){
  		outx += StreamsArr[i].skid+" = "+StreamsArr[i].barr.length+"#np#";
  	}
  	socket.emit("liststreams",outx);
  //function streamobj(skid,barr,soft,device){  
  }
  else{
    var tar = msg.split('---');
    var tit = tar[0];
    var indx = parseInt(tar[1]);
    var counter = 0;
    var outar = new Array();
    //console.log("StreamsArr.length = "+StreamsArr.length);
    for(var i=0;i<=StreamsArr.length-1;i++){
      //console.log(StreamsArr[i].skid.trim()+" == "+tit.trim());
      if(StreamsArr[i].skid.trim() == tit.trim()){
        //console.log("...found "+counter);
        for(var j=0;j<=StreamsArr[i].barr.length;j++){
          if(indx < counter){
            outar[outar.length] = StreamsArr[i].barr[j];
          }
          counter++;
        }
      }
    }
    //console.log("= "+outar.length);
    socket.emit("showstream",outar);
  }
});

socket.on('save1', function(msg){
  //console.log("---- got");
  socket.emit("run1",msg);
  //socket.emit("justgot","");
});

	socket.on('streammessage', function (data) {
	        var fileName = uuid.v4();
	        
	        socket.emit('ffmpeg-output', 0);

	        writeToDisk(data.audio.dataURL, fileName + '.wav');

	        // if it is chrome
	        if (data.video) {
	            writeToDisk(data.video.dataURL, fileName + '.webm');
	            merge(socket, fileName);
	        }

	        // if it is firefox or if user is recording only audio
	        else socket.emit('merged', fileName + '.wav');
	});

	socket.on('message', function(msg) {
		//const buf2 = Buffer.from(msg);
		////console.log("message is : "+roughSizeOfObject(msg)+" - "+ objToString(msg));
      //var json = JSON.parse(msg);
      //rtc.fire(json.eventName, json.data, socket);
    });

    socket.on('close', function() {
      iolog('close');

     
    });

//###################################################

socket.emit('message','Hello from mediarecorder-to-rtmp server!');
	socket.emit('message','Please set rtmp destination before start streaming.');
	
	var ffmpeg_process, feedStream=false;
	socket.on('config_rtmpDestination',function(m){
		if(typeof m != 'string'){
			socket.emit('fatal','rtmp destination setup error.');
			return;
		}
		var regexValidator=/^rtmp:\/\/[^\s]*$/;//TODO: should read config
		if(!regexValidator.test(m)){
			socket.emit('fatal','rtmp address rejected.');
			return;
		}
		socket._rtmpDestination=m;
		socket.emit('message','rtmp destination set to:'+m);
	}); 
	//socket._vcodec='libvpx';//from firefox default encoder
	socket.on('config_vcodec',function(m){
		if(typeof m != 'string'){
			socket.emit('fatal','input codec setup error.');
			return;
		}
		if(!/^[0-9a-z]{2,}$/.test(m)){
			socket.emit('fatal','input codec contains illegal character?.');
			return;
		}//for safety
		socket._vcodec=m;
	}); 	


	socket.on('start',function(m){
		if(ffmpeg_process || feedStream){
			
			socket.emit('fatal','stream already started.');
			return;
		}
		if(!socket._rtmpDestination){
			socket.emit('fatal','no destination given.');
			return;
		}
		
		var ops=[
			'-i','-',
			'-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency',  // video codec config: low latency, adaptive bitrate
			'-c:a', 'aac', '-ar', '44100', '-b:a', '64k', // audio codec config: sampling frequency (11025, 22050, 44100), bitrate 64 kbits
			'-y', //force to overwrite
			'-use_wallclock_as_timestamps', '1', // used for audio sync
			'-async', '1', // used for audio sync
			//'-filter_complex', 'aresample=44100', // resample audio to 44100Hz, needed if input is not 44100
			//'-strict', 'experimental', 
			'-bufsize', '1000',
			'-f', 'flv', socket._rtmpDestination
		];
		
		console.log(socket._rtmpDestination);
		ffmpeg_process=spawn('ffmpeg', ops);
		feedStream=function(data){
			
			ffmpeg_process.stdin.write(data);
			//write exception cannot be caught here.	
		}

		ffmpeg_process.stderr.on('data',function(d){
			socket.emit('ffmpeg_stderr',''+d);
		});
		ffmpeg_process.on('error',function(e){
			console.log('child process error'+e);
			socket.emit('fatal','ffmpeg error!'+e);
			feedStream=false;
			socket.disconnect();
		});
		ffmpeg_process.on('exit',function(e){
			console.log('child process exit'+e);
			socket.emit('fatal','ffmpeg exit!'+e);
			socket.disconnect();
		});
	});

	socket.on('binarystream',function(m){
		if(!feedStream){
			socket.emit('fatal','rtmp not set yet.');
			//ffmpeg_process.stdin.end();
			//ffmpeg_process.kill('SIGINT');
			return;
		}
		feedStream(m);
	});
	socket.on('disconnect', function () {
		feedStream=false;
		if(ffmpeg_process)
		try{
			ffmpeg_process.stdin.end();
			ffmpeg_process.kill('SIGINT');
		}catch(e){console.warn('killing ffmoeg process attempt failed...');}
	});
	socket.on('error',function(e){
		
		console.log('socket.io error:'+e);
	});



//###################################################	    

});
try{
http0.listen(9669, function(){
  //console.log('listening on *:9669');
});
}catch(ex){}

function writeToDisk(dataURL, fileName) {
    var fileExtension = fileName.split('.').pop(),
        fileRootNameWithBase = './uploads/' + fileName,
        filePath = fileRootNameWithBase,
        fileID = 2,
        fileBuffer;

    // @todo return the new filename to client
    while (fs.existsSync(filePath)) {
        filePath = fileRootNameWithBase + '(' + fileID + ').' + fileExtension;
        fileID += 1;
    }

    dataURL = dataURL.split(',').pop();
    fileBuffer = new Buffer(dataURL, 'base64');
    fs.writeFileSync(filePath, fileBuffer);

    //console.log('filePath', filePath);
}
function roughSizeOfObject( object ) {

	var objectList = [];
	var stack = [ object ];
	var bytes = 0;

	while ( stack.length ) {
	var value = stack.pop();

	if ( typeof value === 'boolean' ) {
	bytes += 4;
	}
	else if ( typeof value === 'string' ) {
	bytes += value.length * 2;
	}
	else if ( typeof value === 'number' ) {
	bytes += 8;
	}
	else if
	(
	typeof value === 'object'
	&& objectList.indexOf( value ) === -1
	)
	{
	objectList.push( value );

	for( var i in value ) {
	stack.push( value[ i ] );
	}
	}
	}
	return bytes;
}
function merge(socket, fileName) {
    var FFmpeg = require('fluent-ffmpeg');

    var audioFile = path.join(__dirname, 'uploads', fileName + '.wav'),
        videoFile = path.join(__dirname, 'uploads', fileName + '.webm'),
        mergedFile = path.join(__dirname, 'uploads', fileName + '-merged.webm');

    new FFmpeg({
            source: videoFile
        })
        .addInput(audioFile)
        .on('error', function (err) {
            socket.emit('ffmpeg-error', 'ffmpeg : An error occurred: ' + err.message);
        })
        .on('progress', function (progress) {
            socket.emit('ffmpeg-output', Math.round(progress.percent));
        })
        .on('end', function () {
            socket.emit('merged', fileName + '-merged.webm');
            //console.log('Merging finished !');

            // removing audio/video files
            fs.unlink(audioFile);
            fs.unlink(videoFile);
        })
        .saveToFile(mergedFile);
}


process.on('uncaughtException', function(err) {
    // handle the error safely
    console.log(err)
    // Note: after client disconnect, the subprocess will cause an Error EPIPE, which can only be caught this way.
})


console.log("############ hi 1");