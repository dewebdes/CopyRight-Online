var fs = require("fs");
var uuid = require('node-uuid');
var port = process.argv[2] || 6907;
var path = require('path');
var exec = require('child_process').exec;

var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var url = require('url');
//var socks = 

var regalpha = "،. 123456789,0-/q_wertyuiopasdfghjklzxc،v#bn@mآ?&:=ضصثقفغعهخحجچشسیبلاتنمکگپظطزرذدئوژ";
function havsqlinj(dt){
  for (var k in dt){
      //if (typeof target[k] !== 'function') {
  //         alert("Key i " + k + ", value is" + target[k]);
  var st=dt[k];

      //}
  var ret=false;
  var urstring=st;
  if(isNaN(st)==true){
  urstring=(st.toLowerCase());
  }
  var dlength = (urstring.length);
  //$thisWordCodeVerdeeld = array();
  for (var ix=0; ix<dlength; ix++) {
  if (regalpha.indexOf(urstring[ix]) > -1) {
  a=1;
  }else{
  if(((urstring[ix]).charCodeAt(0) != 46) && ((urstring[ix]).charCodeAt(0) != 37) && ((urstring[ix]).charCodeAt(0) != 32) && ((urstring[ix]).charCodeAt(0) != 10) && ((urstring[ix]).charCodeAt(0) != 8204)){
  //echo("<script>alert('" . ord($urstring[$i]) . "');</script>");
  ret=true;
  //console.log("st bad::" + st + "badchar = (" + urstring[ix] + ") ascii=" + (urstring[ix]).charCodeAt(0));
  return true;
  }
  //return;

  }
  }
  }

}



function cash(cmd,prm,res){
this.cmd=cmd;
this.prm=prm;
this.res=res;
}

var cashar=new Array();

function getcash(c,p){
  for(var i=0;i<=cashar.length-1;i++){
    if(cashar[i].cmd==c){
      if(cashar[i].prm==p){
        return cashar[i].res;
      }
    }
  }
return "ns";
}



function objToString (obj) {
	var str = '';
	for (var p in obj) {
	if (obj.hasOwnProperty(p)) {
	str += p + '::' + obj[p] + '\n';
	}
	}
	return str;
}

var iolog = function() {};

for (var i = 0; i < process.argv.length; i++) {
  var arg = process.argv[i];
  if (arg === "-debug") {
    iolog = function(msg) {
      //console.log(msg);
    };
    //console.log('Debug mode on!');
  }
}


// Used for callback publish and subscribe
if (typeof rtc === "undefined") {
  var rtc = {};
}
//Array to store connections
rtc.sockets = [];

rtc.rooms = {};

// Holds callbacks for certain events.
rtc._events = {};

rtc.on = function(eventName, callback) {
  rtc._events[eventName] = rtc._events[eventName] || [];
  rtc._events[eventName].push(callback);
};

rtc.fire = function(eventName, _) {
  var events = rtc._events[eventName];
  var args = Array.prototype.slice.call(arguments, 1);

  if (!events) {
    return;
  }

  for (var i = 0, len = events.length; i < len; i++) {
    events[i].apply(null, args);
  }
};


// generate a 4 digit hex code randomly
function S4() {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}

// make a REALLY COMPLICATED AND RANDOM id, kudos to dennis
function id() {
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

rtc.getSocket = function(id) {
  var connections = rtc.sockets;
  if (!connections) {
    // TODO: Or error, or customize
    return;
  }

  for (var i = 0; i < connections.length; i++) {
    var socket = connections[i];
    if (id === socket.id) {
      return socket;
    }
  }
};


function notifydevice(id){
	

	var sockets = io.sockets.sockets;
	for(var socketId in sockets)
	{
	  var socket = sockets[socketId]; //loop through and do whatever with each connected socket
	  //...
	  if(socket.device==id){
			socket.emit("runnotify","");
		}
	}

}
app.get('/', function(req, res){
  res.send('<h1>Hello world, My name is MaximORM.</h1>');
});
app.get('/samana-addlog', function(req, res){
  var logid = "0";
  //console.log(req);
  var ip = req.connection.remoteAddress;
  var request = require('request');
  

  var urlprm = decodeURI(req.url).split("?");
  urlprm = urlprm[1].split("&");
  ip = urlprm[0].split("=")[1].split("%")[0];
  var dlog = urlprm[1].split("=")[1];
  //console.log("samana log: "+ip+","+dlog);

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"getDeviceIdFromIp", dip: ip, log:dlog };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		//console.log("device : "+body.trim()+" .");
		var ddevice = body.trim();
		var entry = dlog;//req.body;

    notifydevice(ddevice);
	   
     var s_tablename = "sam_logs";
    var s_flst = "dentry,dtime,deviceid";
    var dtime = Date.now();
    var s_vlst = "#sq#"+entry+"#sq#,#sq#"+dtime+"#sq#,#sq#"+ddevice+"#sq#";
    var s_where = "dtime=#sq#" + dtime + "#sq# AND deviceid=#sq#" + ddevice + "#sq#";

		//var propertiesObject = { api:"sql",cmd:"addLogForDevice", deviceid: device, dentry: entry };
		var propertiesObject = { api:"sql",cmd:"insertorupdate",project: "samana", tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: ddevice  };

		request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
			if(err) { console.log("**ERROR: "+err); return; }
			logid = body.trim();
			res.send(body);
		});
		
	});
  
});



var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "50TopZitedu#ch",
  database: "wordpress"
});


con.connect(function(err) {
    if (err) throw err;
    //console.log("Connected!");
    //var sql = "insert into wp_apoch_view_page (ddata,dresp,dur,pnum,vnum,dlastupdate) values('fulldata','response','ajaxurl','pgnum','vnnum','5/14/2019 1:57:31 PM')";
    
  
});



var StreamsArr = new Array();
function streamobj(skid,barr,soft,device){
	this.skid = skid;
	this.barr = barr;
}
function saveBlob(skid,blb,soft,device){
	//insert into wp_ipz_stream (sid,dkey,dsoft,dplat,tit,ownerTbl,ownerRec,isSingle,isExist,isNew) values(6,#sq#key#sq#,#sq#soft#sq#,#sq#plat#sq#,#sq#tit#sq#,0,0,1,0,0)
	var fnd = false;
	for(var i=0;i<=StreamsArr.length-1;i++){
		if(StreamsArr[i].skid == skid){
			fnd = true;
			for(var j=0;j<=blb.length-1;j++){
				StreamsArr[i].barr[StreamsArr[i].barr.length] = blb[j];
			}
		}
	}
	if(fnd==false){
		var nc = new streamobj(skid,blb,soft,device);
		StreamsArr[StreamsArr.length] = nc;
	}
}

io.origins('*:*');
const iplocation = require("iplocation").default;

function replaceallstr(ts, tv, rv) {
while (ts.indexOf(tv) > -1) {
ts = ts.replace(tv, rv);
}
return ts;
}

function gettimetick() {
var date = new Date();
var ticks = date.getTime();
return ticks;
}

function isnullval(tval) {
retval = false;
try {
if ((tval == "") || (tval == undefined) || (tval == null) || (tval==NaN) || (jQuery.trim(tval) == "")) { retval = true; }
} catch (ex) {
retval = false;
}
return retval;
}

var capsAr = new Array();
function captureobj(tit,bs){
  this.tit = tit;
  this.bs = bs;
}

io.on('connection', function(socket){

	iolog('connect');

    socket.id = id();
    iolog('new socket got id: ' + socket.id);

    rtc.sockets.push(socket);


  //console.log('connect... 1');
  socket.ip = "";
  socket.sys = "";
  socket.tkn = "";
  socket.user = "";
  socket.project = "";
  socket.device = "0";
//console.log('connect... 2');
  ////console.log('a user connected');
  //socket.handshake.headers ['X-FORWARDED-FOR']
  var address = socket.handshake.address;
  socket.ip = address.address+":"+address.port;
  ////console.log('New connection from ' + address.address + ':' + address.port);
//console.log('connect... 3');
  var socketId = socket.id;
  //var clientIp = request.connection.remoteAddress;//socket.request.connection.remoteAddress;
var ip = socket.handshake.headers ['x-forwarded-for'];//socket.handshake.headers ['X-FORWARDED-FOR'];//socket.request.connection._peername.address;//socket.handshake.address;//socket.handshake.headers ['X-FORWARDED-FOR'];//socket.ip;//socket.request.connection.remoteAddress;

//var socketId = client.id;
//var clientIp = client.request.connection.remoteAddress;

 // socket.ip = clientIp;
 //socket.emit('setStreams', body.trim());

//console.log('connect... 4 '+ip);


iplocation(ip, [], (error, res) => {

  ////console.log("res ip loc = "+JSON.stringify(res));
  // {"country":"IR","countryCode":"IR","region":"Tehran","regionCode":"","city":"Jamshidiyeh","postal":"","ip":"85.133.201.5","latitude":35.7128,"longitude":51.3806,"timezone":""}
  socket.emit("iploc",res);

})


socket.ip = ip;
 //console.log(JSON.stringify(socket.handshake.headers));
  socket.on('disconnect', function(){
    ////console.log('user disconnected');
  });

socket.on('saveblob', function(msg){
	//console.log("save blobs :: "+msg.length);
	////console.log("save blobs :: "+msg);
	saveBlob(socket.id,msg,'web','chrome');
});

socket.on('getfile', function(msg){

  
  fs.readFile('/home/kevin/MediaServer/final/uploads/'+msg.fn, (err, data) => {
  if (err) throw err;
  socket.emit("getfile",{fn:msg.fn,bin:data});
  });

});

socket.on('getstreams', function(msg){
  if(msg.length==0){
  	var outx = "";
  	for(var i=0;i<=StreamsArr.length-1;i++){
  		outx += StreamsArr[i].skid+"#np#";
  	}
  	socket.emit("liststreams",outx);
  //function streamobj(skid,barr,soft,device){  
  }
  else{
    var tar = msg.split('---');
    var tit = tar[0];
    var indx = parseInt(tar[1]);
    var counter = 0;
    var outar = new Array();
    //console.log("StreamsArr.length = "+StreamsArr.length);
    for(var i=0;i<=StreamsArr.length-1;i++){
      //console.log(StreamsArr[i].skid.trim()+" == "+tit.trim());
      if(StreamsArr[i].skid.trim() == tit.trim()){
        //console.log("...found "+counter);
        for(var j=0;j<=StreamsArr[i].barr.length;j++){
          if(indx < counter){
            outar[outar.length] = StreamsArr[i].barr[j];
          }
          counter++;
        }
      }
    }
    //console.log("= "+outar.length);
    socket.emit("showstream",outar);
  }
});

socket.on('save1', function(msg){
  //console.log("---- got");
  //socket.emit("run1",msg);
  socket.emit("justgot","");
});
socket.on('select', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    //var s_vlst = prm[2];
    var s_where = prm[2];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"select",project: socket.project, tablename: s_tablename, flst: s_flst, where: s_where, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//console.log("selectfill: "+body.trim())
		socket.emit('selectFill', body.trim());
		//socket.device = body;
		//console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("loginme", us+","+ps);
socket.on('loginme', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var us = prm[0];
    var ps = prm[1];
    //var s_vlst = prm[2];
    //var s_where = prm[2];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"loginme", dus: us, dps: ps, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('loginres', "OK");
		}else{
			socket.emit('loginres', "ERR");
		}
		//socket.device = body;
		////console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("regme", name+","+ us+","+ps+","+autyp);
socket.on('regme', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var s_name = prm[0];
    var s_us = prm[1];
    var s_ps = prm[2];
    var s_autyp = prm[3];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"regme", name: s_name, us: s_us, ps: s_ps, autyp: s_autyp, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('regres', body);
		//socket.device = body;
		////console.log("socket.device = "+socket.device);
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('regres', "OK");
		}else{
			socket.emit('regres', "ERR");
		}
	});

});
//mSocket.emit("getdivelist", "");
socket.on('getdivelist', function(msg){
   
	var request = require('request');
	//console.log("get divive list...");
	var propertiesObject = { api:"sql",cmd:"getdivelist", project: socket.project, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
	
		//console.log("ret: "+body);
		socket.emit('setdevicelist', body);
	
	});

});
socket.on('savemapcap', function(msg){
  var nc = new captureobj(msg.tit,msg.bs.split(',')[1]);
  var fnd = false;
  for(var i=0;i<=capsAr.length-1;i++){
    if(capsAr[i].tit == msg.tit){
      fnd = true;
      capsAr[i].bs = msg.bs.split(',')[1];
      break;
    }
  }
  if(fnd == false){
    capsAr[capsAr.length] = nc;
  }
});
socket.on('getmapcap', function(msg){
  //var nc = new captureobj(msg.tit,msg.bs);
  var fnd = false;
  for(var i=0;i<=capsAr.length-1;i++){
    if(capsAr[i].tit == msg.tit){
      fnd = true;
      socket.emit("setmapcap",capsAr[i].bs);
      break;
    }
  }
  if(fnd == false){
    //capsAr[capsAr.length] = nc;
  }
});


socket.on('BIGinsertorupdate', function(msg){
    //console.log('BIG insertorupdate: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    var s_vlst = prm[2];
    var s_where = prm[3];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

//console.log("BIG  = "+msg);

    //===============================================
        
        retid = "0";
        con.query("SELECT * FROM wp_" + s_tablename + " WHERE " + s_where + ";", function(err, rows, fields) {
          try{
          rows.forEach(function(row) {
            retid = row.id;
          });
          //console.log('Finish');
          }catch(ex){retid="0";}
        });

        if(retid == 0){
          var query="insert into wp_" + s_tablename + " (sid," + s_flst + ",ownerTbl,ownerRec,isSingle,isExist,isNew) values(6," + s_vlst + ",0,0,1,0,0)";
          query= replaceallstr(query,"#sq#","'");
          query= replaceallstr(query,"{project}",socket.project);
          query= replaceallstr(query,"{device}",socket.device);
          console.log('rep ok = '+query.indexOf('#sq#'));
          
          con.query(query, function (err, result) {
                      if (err) throw err;
                      console.log("1 record inserted A");
                    });

        }else{

          var flar = s_flst.split(",");
          var vlar = s_vlst.split(",");

          var query="update wp_" + s_tablename + " set ";

          for(iv=0;iv<=flar.length-1;iv++){
            query=query + flar[iv] + "=" + vlar[iv];
            if(iv<flar.length-1){
              query=query + ",";
            }
          }

          query=query + " WHERE " + where + ";";
          query= replaceallstr(query,"#sq#","'");
          query= replaceallstr(query,"{project}",socket.project);
          query= replaceallstr(query,"{device}",socket.device);
          
console.log(query);
          con.query(query, function (err, result) {
                      if (err) throw err;
                      console.log("1 record inserted B");
                      
                    });

        }
        socket.emit('BigQueryFin',s_tablename);

     //   $rtv = $retid;


    //=================================================
});


  socket.on('insertorupdate', function(msg){
    //console.log('insertorupdate: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    var s_vlst = prm[2];
    var s_where = prm[3];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"insertorupdate",project:socket.project, tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: socket.device  };
//console.log("***"+socket.device);
	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		//socket.device = body;
		//console.log("insertorupdate = "+body);
	});

});

  socket.on('devicedetect', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    socket.sys = prm[0];
    socket.tkn = prm[1];
    socket.project = prm[2];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"DetectDevice", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		socket.device = body.trim();
		//console.log("socket.device = "+socket.device);
    socket.emit("setdeviceid",socket.device);

      var propertiesObject = { api:"sql",cmd:"DetectUser", dv: socket.device };

      request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
        if(err) { console.log("**ERROR: "+err); return; }
        socket.user = body.trim();
        //console.log("socket.user = "+socket.user);
        socket.emit("setuserid",socket.user);
      });



	});

  });

  socket.on('DetectUser', function (data) {
      var request = require('request');
      var propertiesObject = { api:"sql",cmd:"DetectUser", dv: data };

      request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
        if(err) { console.log("**ERROR: "+err); return; }
        socket.user = body.trim();
        //console.log("socket.user = "+socket.user);
        socket.emit("setuserid",socket.user);
      });

  });

	socket.on('streammessage', function (data) {
	        var fileName = uuid.v4();
	        
	        socket.emit('ffmpeg-output', 0);

	        writeToDisk(data.audio.dataURL, fileName + '.wav');

	        // if it is chrome
	        if (data.video) {
	            writeToDisk(data.video.dataURL, fileName + '.webm');
	            merge(socket, fileName);
	        }

	        // if it is firefox or if user is recording only audio
	        else socket.emit('merged', fileName + '.wav');
	});

	socket.on('message', function(msg) {
		//const buf2 = Buffer.from(msg);
		////console.log("message is : "+roughSizeOfObject(msg)+" - "+ objToString(msg));
      //var json = JSON.parse(msg);
      //rtc.fire(json.eventName, json.data, socket);
    });

    socket.on('close', function() {
      iolog('close');

    });
    

    // call the connect callback
    rtc.fire('connect', rtc);

  

});

http.listen(6907, function(){
  //console.log('listening on *:6907');
});

function writeToDisk(dataURL, fileName) {
    var fileExtension = fileName.split('.').pop(),
        fileRootNameWithBase = './uploads/' + fileName,
        filePath = fileRootNameWithBase,
        fileID = 2,
        fileBuffer;

    // @todo return the new filename to client
    while (fs.existsSync(filePath)) {
        filePath = fileRootNameWithBase + '(' + fileID + ').' + fileExtension;
        fileID += 1;
    }

    dataURL = dataURL.split(',').pop();
    fileBuffer = new Buffer(dataURL, 'base64');
    fs.writeFileSync(filePath, fileBuffer);

    //console.log('filePath', filePath);
}
function roughSizeOfObject( object ) {

	var objectList = [];
	var stack = [ object ];
	var bytes = 0;

	while ( stack.length ) {
	var value = stack.pop();

	if ( typeof value === 'boolean' ) {
	bytes += 4;
	}
	else if ( typeof value === 'string' ) {
	bytes += value.length * 2;
	}
	else if ( typeof value === 'number' ) {
	bytes += 8;
	}
	else if
	(
	typeof value === 'object'
	&& objectList.indexOf( value ) === -1
	)
	{
	objectList.push( value );

	for( var i in value ) {
	stack.push( value[ i ] );
	}
	}
	}
	return bytes;
}
function merge(socket, fileName) {
    var FFmpeg = require('fluent-ffmpeg');

    var audioFile = path.join(__dirname, 'uploads', fileName + '.wav'),
        videoFile = path.join(__dirname, 'uploads', fileName + '.webm'),
        mergedFile = path.join(__dirname, 'uploads', fileName + '-merged.webm');

    new FFmpeg({
            source: videoFile
        })
        .addInput(audioFile)
        .on('error', function (err) {
            socket.emit('ffmpeg-error', 'ffmpeg : An error occurred: ' + err.message);
        })
        .on('progress', function (progress) {
            socket.emit('ffmpeg-output', Math.round(progress.percent));
        })
        .on('end', function () {
            socket.emit('merged', fileName + '-merged.webm');
            //console.log('Merging finished !');

            // removing audio/video files
            fs.unlink(audioFile);
            fs.unlink(videoFile);
        })
        .saveToFile(mergedFile);
}

  // manages the built-in room functionality
  rtc.on('join_room', function(data, socket) {
    iolog('join_room');

    var connectionsId = [];
    var roomList = rtc.rooms[data.room] || [];

    roomList.push(socket.id);
    rtc.rooms[data.room] = roomList;


    for (var i = 0; i < roomList.length; i++) {
      var id = roomList[i];

      if (id == socket.id) {
        continue;
      } else {

        connectionsId.push(id);
        var soc = rtc.getSocket(id);

        // inform the peers that they have a new peer
        if (soc) {
          soc.send(JSON.stringify({
            "eventName": "new_peer_connected",
            "data":{
              "socketId": socket.id
            }
          }), function(error) {
            if (error) {
              //console.log(error);
            }
          });
        }
      }
    }
    // send new peer a list of all prior peers
    socket.send(JSON.stringify({
      "eventName": "get_peers",
      "data": {
        "connections": connectionsId,
        "you": socket.id
      }
    }), function(error) {
      if (error) {
        //console.log(error);
      }
    });
  });

  //Receive ICE candidates and send to the correct socket
  rtc.on('send_ice_candidate', function(data, socket) {
    iolog('send_ice_candidate');
    var soc = rtc.getSocket(data.socketId);

    if (soc) {
      soc.send(JSON.stringify({
        "eventName": "receive_ice_candidate",
        "data": {
          "label": data.label,
          "candidate": data.candidate,
          "socketId": socket.id
        }
      }), function(error) {
        if (error) {
          //console.log(error);
        }
      });

      // call the 'recieve ICE candidate' callback
      rtc.fire('receive ice candidate', rtc);
    }
  });

  //Receive offer and send to correct socket
  rtc.on('send_offer', function(data, socket) {
    iolog('send_offer');
    var soc = rtc.getSocket(data.socketId);

    if (soc) {
      soc.send(JSON.stringify({
        "eventName": "receive_offer",
        "data": {
          "sdp": data.sdp,
          "socketId": socket.id
      }
      }), function(error) {
        if (error) {
          //console.log(error);
        }
      });
    }
    // call the 'send offer' callback
    rtc.fire('send offer', rtc);
  });

  //Receive answer and send to correct socket
  rtc.on('send_answer', function(data, socket) {
    iolog('send_answer');
    var soc = rtc.getSocket( data.socketId);

    if (soc) {
      soc.send(JSON.stringify({
        "eventName": "receive_answer",
        "data" : {
          "sdp": data.sdp,
          "socketId": socket.id
        }
      }), function(error) {
        if (error) {
          //console.log(error);
        }
      });
      rtc.fire('send answer', rtc);
    }
  });


