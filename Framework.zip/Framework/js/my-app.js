﻿//var app = new Framework7({
//    root: '#app',

//});
var app = new Framework7({
    // App root element
    root: '#app',
    // App Name
    name: 'owd',
    // App id
    id: 'com.myapp.test',

    panel: {
        swipe: 'both',
    },
    
    // Add default routes
    routes: [
        {
            path: '/p1/',
            pageName: 'page1',
            on: {pageAfterIn: function (e, page) {}}
        },
    {
        path: '/p2/',
        pageName: 'page2',
            },
    {
        path: '/p3/',
        pageName: 'page3',
        
    },
     {
         path: '/p4/',
         pageName: 'page4',
         on: { pageAfterIn: function (e, page) { } }
     },
     {
         path: '/p5/',
         pageName: 'page5',
         on: { pageAfterIn: function (e, page) { } }
     },
     {
         path: '/p6/',
         pageName: 'page6',
         on: { pageAfterIn: function (e, page) { } }
     },
    
    ],
    clicks: {
        externalLinks: ".external"
},
    // ... other parameters
});

var mainView = app.views.create('.view-main', {
    stackPages: true,
    pushState: true,
});
// slider
var mySwiper = new Swiper('.per1 .swiper-container', {
    autoplay: {
        delay: 5000,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
    pagination: {
        el: '.swiper-pagination',
        type: 'bullets',
        clickable:true,
    },
});
var mySwiper4 = new Swiper('.swiper-4', {
    pagination: '.swiper-4 .swiper-pagination',
    lazyLoading: true,
    spaceBetween: 20,
    slidesPerView: 3
});
function showTooltip() {
    $('.tltip').removeClass('displayno');
    //alert(0);
}